import tensorflow as tf
from tensorflow.keras.layers import (
    Layer, Input, Conv2D, MaxPooling2D, UpSampling2D, Flatten, Reshape,
    Dense, BatchNormalization, LeakyReLU, Add, Dropout
)
from tensorflow.keras.models import Model
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import img_to_array, load_img, ImageDataGenerator
from tensorflow.keras.callbacks import (
    EarlyStopping, ModelCheckpoint, ReduceLROnPlateau, TensorBoard
)
import os

# Custom Keras Layer for Hyperbolic Projection
class HyperbolicProjection(Layer):
    def __init__(self, curvature=1.0, **kwargs):
        super(HyperbolicProjection, self).__init__(**kwargs)
        self.curvature = curvature

    def call(self, inputs):
        norm = tf.norm(inputs, axis=-1, keepdims=True)
        sqrt_c = tf.sqrt(tf.cast(self.curvature, inputs.dtype))
        scaled_norm = sqrt_c * norm
        denominator = tf.maximum(scaled_norm, 1e-8)  # Avoid division by zero
        expmap = tf.math.tanh(scaled_norm) * inputs / denominator
        return expmap

    def get_config(self):
        config = super(HyperbolicProjection, self).get_config()
        config.update({'curvature': self.curvature})
        return config

# Custom SSIM loss function
def ssim_loss(y_true, y_pred):
    return 1 - tf.reduce_mean(tf.image.ssim(y_true, y_pred, max_val=1.0))

# Function to load and preprocess a single image
def load_and_preprocess_image(image_path, image_size=(128, 128)):
    img = load_img(image_path, target_size=image_size, color_mode='rgb')
    img_array = img_to_array(img).astype('float32') / 255.0
    return img_array

# Function to augment the image and create a dataset
def create_dataset_from_image(img_array, num_samples=1000):
    datagen = ImageDataGenerator(
        rotation_range=10,
        horizontal_flip=True,
        zoom_range=0.1,
        width_shift_range=0.1,
        height_shift_range=0.1
    )
    img_array = np.expand_dims(img_array, axis=0)
    data_generator = datagen.flow(img_array, batch_size=1)
    augmented_images = np.vstack([next(data_generator) for _ in range(num_samples)])
    return augmented_images

# Load and preprocess the image
image_path = 'data/Mahayana.png'  # Replace with your image path
image_size = (128, 128)  # Define the target image size
img_array = load_and_preprocess_image(image_path, image_size)

# Create a dataset from the single image using data augmentation
data = create_dataset_from_image(img_array, num_samples=1000)

# Define the input shape
input_shape = data.shape[1:]  # (height, width, channels)

# Input layer
input_img = Input(shape=input_shape, name='input_img')

# Flatten the input for the hyperbolic projection
flattened_input = Flatten()(input_img)

# Hyperbolic Projection Layer
hyperbolic_projection = HyperbolicProjection()(flattened_input)

# Reshape back to image dimensions
reshaped_projection = Reshape((input_shape[0], input_shape[1], input_shape[2]))(hyperbolic_projection)

# Build the encoder
# First Convolutional Layer
x = Conv2D(64, (3, 3), padding='same')(reshaped_projection)
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)
skip1 = x  # Skip connection
x = MaxPooling2D((2, 2), padding='same')(x)

# Second Convolutional Layer
x = Conv2D(128, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)
skip2 = x  # Skip connection
x = MaxPooling2D((2, 2), padding='same')(x)

# Third Convolutional Layer
x = Conv2D(256, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)
x = MaxPooling2D((2, 2), padding='same')(x)

# Flatten and Latent Space
x = Flatten()(x)
x = Dense(512)(x)
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)
x = Dropout(0.5)(x)
latent = Dense(256, activation='relu', name='latent_space')(x)

# Build the decoder
x = Dense(16 * 16 * 256)(latent)
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)
x = Reshape((16, 16, 256))(x)

# First UpSampling and Convolutional Layer
x = UpSampling2D((2, 2))(x)
x = Conv2D(256, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)

# Second UpSampling and Convolutional Layer with Skip Connection
x = UpSampling2D((2, 2))(x)
x = Conv2D(128, (3, 3), padding='same')(x)
x = Add()([x, skip2])  # Skip connection
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)

# Third UpSampling and Convolutional Layer with Skip Connection
x = UpSampling2D((2, 2))(x)
x = Conv2D(64, (3, 3), padding='same')(x)
x = Add()([x, skip1])  # Skip connection
x = BatchNormalization()(x)
x = LeakyReLU(alpha=0.1)(x)

# Output Layer
decoded = Conv2D(3, (3, 3), activation='sigmoid', padding='same')(x)

# Build the model
autoencoder = Model(inputs=input_img, outputs=decoded)

# Compile the model
optimizer = tf.keras.optimizers.Adam(learning_rate=1e-3)
autoencoder.compile(optimizer=optimizer, loss=ssim_loss)

# Callbacks
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
model_checkpoint = ModelCheckpoint('best_model.keras', save_best_only=True)  # Updated extension
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5)
tensorboard = TensorBoard(log_dir='./logs')

# Train the model
history = autoencoder.fit(
    data, data,
    epochs=100,
    batch_size=32,
    shuffle=True,
    validation_split=0.1,
    callbacks=[early_stopping, model_checkpoint, reduce_lr, tensorboard],
    verbose=1
)

# Load the best model
# Use custom_objects if needed
from tensorflow.keras.models import load_model

autoencoder = load_model('best_model.keras', custom_objects={'HyperbolicProjection': HyperbolicProjection, 'ssim_loss': ssim_loss})

# Evaluate the Model
encoded_model = Model(inputs=autoencoder.input, outputs=autoencoder.get_layer('latent_space').output)
compressed_data = encoded_model.predict(np.expand_dims(img_array, axis=0))
reconstructed_image = autoencoder.predict(np.expand_dims(img_array, axis=0))

# Visualize the original and reconstructed images
plt.figure(figsize=(12, 6))

# Original Image
plt.subplot(1, 2, 1)
plt.imshow(img_array)
plt.title("Original Image")
plt.axis('off')

# Reconstructed Image
plt.subplot(1, 2, 2)
plt.imshow(reconstructed_image[0])
plt.title("Reconstructed Image")
plt.axis('off')

plt.show()

# Output the Latent Space Representation
print("Compressed (Latent Space) Data Shape:", compressed_data.shape)
print("Compressed (Latent Space) Data:\n", compressed_data)
